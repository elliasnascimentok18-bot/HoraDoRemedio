package com.elias.horadoremedio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int GREEN=Color.rgb(24,124,88), DARK=Color.rgb(29,50,43), MUTED=Color.rgb(98,113,106);
    private MedicineDb db;
    private LinearLayout root;
    private boolean large=false;
    private final ArrayList<String> chosenTimes=new ArrayList<>();
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); db=new MedicineDb(this);
        getWindow().setStatusBarColor(GREEN);getWindow().setNavigationBarColor(Color.WHITE);
        large=getPreferences(0).getBoolean("large",false);
        askNotificationPermission(); showHome();
        if(getIntent().hasExtra("id")) {
            long id=getIntent().getLongExtra("id",-1), scheduled=getIntent().getLongExtra("scheduled",0);
            if(scheduled>0) getWindow().getDecorView().post(()->confirmDose(id,scheduled));
        }
    }
    private void askNotificationPermission() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7);
    }
    private int dp(float amount) {return (int)(getResources().getDisplayMetrics().density*amount+.5f);}
    private LinearLayout vertical() { LinearLayout l=new LinearLayout(this); l.setOrientation(1);return l; }
    private TextView text(String value,int size,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size+(large?3:0));t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD);return t;
    }
    private void space(LinearLayout parent,int height) { View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height))); }
    private Button button(String label,LinearLayout parent,View.OnClickListener action) {
        Button b=new Button(this);b.setText(label);b.setTextSize(large?19:15);b.setAllCaps(false);
        b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));
        b.setMinHeight(dp(large?58:48));parent.addView(b,new LinearLayout.LayoutParams(-1,-2));b.setOnClickListener(action);return b;
    }
    private void begin(String title,String subtitle) {
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(247,250,248));
        root=vertical();root.setPadding(dp(22),dp(28),dp(22),dp(35)); scroll.addView(root);setContentView(scroll);
        root.addView(text(title,29,DARK,true));space(root,5);root.addView(text(subtitle,15,MUTED,false));space(root,24);
    }
    private LinearLayout card() {
        LinearLayout l=vertical();l.setPadding(dp(16),dp(15),dp(16),dp(15));
        android.graphics.drawable.GradientDrawable shape=new android.graphics.drawable.GradientDrawable();shape.setColor(Color.WHITE);shape.setCornerRadius(dp(18));
        shape.setStroke(dp(1),Color.rgb(226,235,229));l.setBackground(shape);
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);params.bottomMargin=dp(12);root.addView(l,params);return l;
    }
    private void showHome() {
        begin("Hora do Remédio 💊","Sua rotina de cuidados, sem precisar de internet.");
        button("+ Adicionar medicamento",root,v->showForm());space(root,12);
        button("Ver histórico",root,v->showHistory());space(root,12);
        button(large?"Modo de letras grandes: ligado":"Modo de letras grandes: desligado",root,v->{
            large=!large;getPreferences(0).edit().putBoolean("large",large).apply();showHome();
        });space(root,22);
        List<MedicineDb.Medicine> medicines=db.all();
        root.addView(text("Meus medicamentos",22,DARK,true));space(root,14);
        if(medicines.isEmpty()) {LinearLayout box=card();box.addView(text("Nenhum medicamento cadastrado ainda.",17,MUTED,false));}
        for(MedicineDb.Medicine m:medicines) {
            LinearLayout box=card();box.addView(text(m.name,21,DARK,true));space(box,5);
            box.addView(text("Dose: "+m.dose,16,MUTED,false));space(box,5);
            box.addView(text("Horários: "+m.times.replace(",","  •  "),16,MUTED,false));space(box,5);
            box.addView(text(m.stock==0?"Estoque: não informado ou esgotado":"Estoque: "+m.stock+" unidade(s)",14,m.stock<=3?Color.rgb(183,88,25):MUTED,false));
            space(box,10);
            for(String hhmm:m.times.split(",")) {
                long scheduled=todayAt(hhmm);
                String label=db.wasTaken(m.id,scheduled)?"✓ Confirmado hoje às "+hhmm:"Confirmar dose das "+hhmm;
                Button b=button(label,box,v->confirmDose(m.id,scheduled));b.setEnabled(!db.wasTaken(m.id,scheduled) && scheduled<=System.currentTimeMillis());
                space(box,6);
            }
            button("Excluir medicamento",box,v->new AlertDialog.Builder(this).setTitle("Excluir "+m.name+"?")
                    .setMessage("O cadastro e o histórico desse medicamento serão excluídos.")
                    .setNegativeButton("Cancelar",null).setPositiveButton("Excluir",(d,w)->{
                        for(String h:m.times.split(","))ReminderScheduler.cancel(this,m.id,h);
                        db.remove(m.id);showHome();
                    }).show());
        }
        space(root,12);root.addView(text("Importante: siga sempre a orientação do profissional de saúde. O aplicativo não recomenda doses nem substitui acompanhamento médico.",13,MUTED,false));
        if(Build.VERSION.SDK_INT>=31) {
            android.app.AlarmManager manager=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);
            if(!manager.canScheduleExactAlarms()) {space(root,14);button("Permitir alarmes pontuais no Android",root,v->{
                try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){Toast.makeText(this,"Confira as permissões do aplicativo nas configurações",Toast.LENGTH_LONG).show();}
            });}
        }
    }
    private static long todayAt(String hhmm) {
        Calendar c=Calendar.getInstance();String[] p=hhmm.split(":");
        c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(p[0]));c.set(Calendar.MINUTE,Integer.parseInt(p[1]));c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        return c.getTimeInMillis();
    }
    private void confirmDose(long id,long scheduled) {
        MedicineDb.Medicine m=db.get(id);if(m==null)return;
        if(scheduled>System.currentTimeMillis()) {Toast.makeText(this,"Esse horário ainda não chegou.",Toast.LENGTH_SHORT).show();return;}
        if(db.wasTaken(id,scheduled)) {Toast.makeText(this,"Essa dose já foi confirmada.",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("Você tomou "+m.name+"?")
            .setMessage(m.dose+"\nConfirme somente depois de tomar. Não tome outra dose apenas porque recebeu um lembrete.")
            .setNegativeButton("Ainda não",null).setPositiveButton("Já tomei",(d,w)->{
                if(db.markTaken(id,scheduled))Toast.makeText(this,"Dose registrada!",Toast.LENGTH_SHORT).show();
                showHome();
            }).show();
    }
    private void showForm() {
        chosenTimes.clear();begin("Novo medicamento","Preencha os dados conforme sua prescrição ou orientação profissional.");
        EditText name=new EditText(this);name.setHint("Nome (ex.: Medicamento A)");name.setSingleLine(true);root.addView(name);
        EditText dose=new EditText(this);dose.setHint("Dose prescrita (ex.: 1 comprimido)");dose.setSingleLine(true);root.addView(dose);
        EditText stock=new EditText(this);stock.setHint("Quantidade em estoque (opcional)");stock.setInputType(2);root.addView(stock);space(root,20);
        TextView timesLabel=text("Horários: nenhum selecionado",17,DARK,true);root.addView(timesLabel);space(root,10);
        button("+ Adicionar horário",root,v->{Calendar c=Calendar.getInstance();new TimePickerDialog(this,(picker,h,min)->{
            String hhmm=String.format(Locale.ROOT,"%02d:%02d",h,min);
            if(!chosenTimes.contains(hhmm))chosenTimes.add(hhmm);
            java.util.Collections.sort(chosenTimes);timesLabel.setText("Horários: "+android.text.TextUtils.join(" • ",chosenTimes));
        },c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();});space(root,10);
        button("Limpar horários",root,v->{chosenTimes.clear();timesLabel.setText("Horários: nenhum selecionado");});space(root,25);
        button("Salvar medicamento",root,v->{
            String n=name.getText().toString().trim(),d=dose.getText().toString().trim(),s=stock.getText().toString().trim();
            if(n.isEmpty()||d.isEmpty()||chosenTimes.isEmpty()) {Toast.makeText(this,"Informe nome, dose e pelo menos um horário.",Toast.LENGTH_LONG).show();return;}
            int qty=0;try {if(!s.isEmpty())qty=Integer.parseInt(s);}catch(NumberFormatException e){Toast.makeText(this,"Estoque inválido.",Toast.LENGTH_SHORT).show();return;}
            if(qty<0){Toast.makeText(this,"Estoque não pode ser negativo.",Toast.LENGTH_SHORT).show();return;}
            long id=db.add(n,d,android.text.TextUtils.join(",",chosenTimes),qty);
            for(String h:chosenTimes)ReminderScheduler.schedule(this,id,h);
            Toast.makeText(this,"Medicamento salvo!",Toast.LENGTH_SHORT).show();showHome();
        });space(root,12);button("Cancelar",root,v->showHome());
    }
    private void showHistory() {
        begin("Histórico","Registros confirmados por você (últimos 100).");
        for(String entry:db.history()){LinearLayout box=card();box.addView(text(entry,16,DARK,false));}
        if(db.history().isEmpty()){LinearLayout box=card();box.addView(text("Nenhuma dose confirmada até agora.",16,MUTED,false));}
        button("Voltar",root,v->showHome());
    }
    @Override public void onBackPressed() {showHome();}
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);setIntent(intent);
        if(intent.hasExtra("id"))confirmDose(intent.getLongExtra("id",-1),intent.getLongExtra("scheduled",0));
    }
}
