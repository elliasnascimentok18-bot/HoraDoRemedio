package com.elias.horadoremedio;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.app.Notification;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        long id=intent.getLongExtra("id",-1); String hhmm=intent.getStringExtra("hhmm");
        if(id<0 || hhmm==null) return;
        MedicineDb.Medicine m=new MedicineDb(context).get(id);
        if(m==null || !java.util.Arrays.asList(m.times.split(",")).contains(hhmm)) return;
        // Reagenda antes de exibir: assim um lembrete não depende da abertura do app.
        ReminderScheduler.schedule(context,id,hhmm);
        NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(new NotificationChannel("medicines","Lembretes de remédios",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(context,MainActivity.class).putExtra("id",id).putExtra("scheduled",intent.getLongExtra("scheduled",System.currentTimeMillis()));
        int notificationId=(int)(id*1440+Integer.parseInt(hhmm.substring(0,2))*60+Integer.parseInt(hhmm.substring(3)));
        PendingIntent pi=PendingIntent.getActivity(context,notificationId,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(context,"medicines").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Hora do remédio: "+m.name).setContentText(m.dose+" • "+hhmm+" — toque para confirmar")
                .setContentIntent(pi).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).build();
        manager.notify(notificationId,n);
    }
}
