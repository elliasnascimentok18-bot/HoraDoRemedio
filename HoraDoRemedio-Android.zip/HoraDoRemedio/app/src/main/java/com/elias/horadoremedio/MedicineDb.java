package com.elias.horadoremedio;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class MedicineDb extends SQLiteOpenHelper {
    public static class Medicine {
        public long id;
        public String name, dose, times;
        public int stock;
        Medicine(long id, String name, String dose, String times, int stock) {
            this.id=id; this.name=name; this.dose=dose; this.times=times; this.stock=stock;
        }
    }
    public MedicineDb(Context context) { super(context, "remedios.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE medicines (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, dose TEXT NOT NULL, times TEXT NOT NULL, stock INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE doses (id INTEGER PRIMARY KEY AUTOINCREMENT, medicine_id INTEGER NOT NULL, scheduled_at INTEGER NOT NULL, taken_at INTEGER NOT NULL, UNIQUE(medicine_id, scheduled_at))");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    public long add(String name, String dose, String times, int stock) {
        ContentValues v=new ContentValues(); v.put("name",name); v.put("dose",dose); v.put("times",times); v.put("stock",stock);
        return getWritableDatabase().insertOrThrow("medicines",null,v);
    }
    public List<Medicine> all() {
        List<Medicine> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,dose,times,stock FROM medicines ORDER BY name",null)) {
            while(c.moveToNext()) result.add(new Medicine(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4)));
        }
        return result;
    }
    public Medicine get(long id) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,dose,times,stock FROM medicines WHERE id=?",new String[]{String.valueOf(id)})) {
            return c.moveToFirst() ? new Medicine(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4)) : null;
        }
    }
    public void remove(long id) {
        getWritableDatabase().delete("medicines","id=?",new String[]{String.valueOf(id)});
        getWritableDatabase().delete("doses","medicine_id=?",new String[]{String.valueOf(id)});
    }
    public boolean wasTaken(long id,long scheduled) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM doses WHERE medicine_id=? AND scheduled_at=?",new String[]{String.valueOf(id),String.valueOf(scheduled)})) { return c.moveToFirst(); }
    }
    public boolean markTaken(long id,long scheduled) {
        Medicine m=get(id);
        if(m==null || wasTaken(id,scheduled)) return false;
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v=new ContentValues(); v.put("medicine_id",id); v.put("scheduled_at",scheduled); v.put("taken_at",System.currentTimeMillis());
            if(db.insertWithOnConflict("doses",null,v,SQLiteDatabase.CONFLICT_IGNORE)==-1) return false;
            if(m.stock>0) db.execSQL("UPDATE medicines SET stock=stock-1 WHERE id=?",new Object[]{id});
            db.setTransactionSuccessful(); return true;
        } finally { db.endTransaction(); }
    }
    public List<String> history() {
        List<String> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT m.name,m.dose,d.taken_at FROM doses d JOIN medicines m ON m.id=d.medicine_id ORDER BY d.taken_at DESC LIMIT 100",null)) {
            java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("dd/MM/yyyy 'às' HH:mm",java.util.Locale.forLanguageTag("pt-BR"));
            while(c.moveToNext()) result.add(c.getString(0)+" • "+c.getString(1)+"\nConfirmado em "+fmt.format(new java.util.Date(c.getLong(2))));
        }
        return result;
    }
}
