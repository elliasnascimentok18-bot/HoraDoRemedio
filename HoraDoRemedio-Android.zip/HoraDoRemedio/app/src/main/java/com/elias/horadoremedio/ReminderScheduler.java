package com.elias.horadoremedio;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public final class ReminderScheduler {
    private ReminderScheduler() {}
    public static long next(String hhmm) {
        String[] parts=hhmm.split(":");
        Calendar now=Calendar.getInstance(); Calendar target=Calendar.getInstance();
        target.set(Calendar.HOUR_OF_DAY,Integer.parseInt(parts[0])); target.set(Calendar.MINUTE,Integer.parseInt(parts[1]));
        target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0);
        if(target.getTimeInMillis()<=now.getTimeInMillis()) target.add(Calendar.DAY_OF_YEAR,1);
        return target.getTimeInMillis();
    }
    private static PendingIntent intent(Context c,long id,String hhmm,long scheduled) {
        Intent i=new Intent(c,ReminderReceiver.class).setAction("reminder."+id+"."+hhmm);
        i.putExtra("id",id);i.putExtra("hhmm",hhmm);i.putExtra("scheduled",scheduled);
        return PendingIntent.getBroadcast(c,(int)(id*1440+Integer.parseInt(hhmm.substring(0,2))*60+Integer.parseInt(hhmm.substring(3))),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context c,long id,String hhmm) {
        long when=next(hhmm); AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi=intent(c,id,hhmm,when);
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
    }
    public static void cancel(Context c,long id,String hhmm) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(intent(c,id,hhmm,0));
    }
    public static void scheduleAll(Context c) {
        for(MedicineDb.Medicine m:new MedicineDb(c).all()) for(String t:m.times.split(",")) schedule(c,m.id,t);
    }
}
