# Hora do Remédio — Android

Aplicativo Android nativo (Java), em português, com dados locais em SQLite e lembretes via `AlarmManager`. Não requer internet e não possui conta ou servidor.

## Como gerar APK

1. Instale o Android Studio com Android SDK 35 e JDK 17.
2. Abra a pasta `HoraDoRemedio` como projeto no Android Studio.
3. Aguarde a sincronização do Gradle (precisa de internet apenas para baixar as ferramentas de desenvolvimento na primeira vez).
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Funções desta primeira versão

- Cadastro de medicamentos com nome, dose, vários horários por dia e estoque inicial opcional.
- Notificações locais diárias, com reagendamento após reiniciar o celular ou alterar hora/fuso.
- Confirmação manual de doses, evitando dupla confirmação para o mesmo horário.
- Histórico das últimas 100 confirmações.
- Exclusão de medicamento e modo de letras grandes.
- Armazenamento privado no dispositivo, sem conexão de rede.

## Limitações importantes

- É um **projeto-fonte**, não um APK compilado. Os alarmes devem ser testados em aparelho Android real.
- No Android 12+, alarmes exatos precisam de permissão especial do usuário. Sem ela, o aplicativo usa alarmes menos precisos; restrições de bateria do fabricante podem atrasar avisos.
- No Android 13+, o usuário precisa autorizar notificações.
- Um aviso não prova que a dose foi tomada; só a confirmação do usuário gera histórico.
- A versão inicial não oferece edição, lembrete de reposição, confirmação pelo cuidador nem backup. O estoque é decrementado em uma unidade por confirmação, independentemente da descrição da dose.
- Horários repetem todos os dias. Mudanças de prescrição precisam ser refletidas no cadastro manualmente.
- Não constitui orientação médica. Nunca altere doses com base no aplicativo.

## Privacidade

Os dados ficam em banco SQLite privado do app, e o backup automático Android está desabilitado. Ao desinstalar o aplicativo, os dados locais podem ser apagados.
